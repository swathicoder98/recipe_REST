from django.contrib import admin
from recipe.models import Recipe,Review

admin.site.register(Recipe)
admin.site.register(Review)
